﻿using System;
using System.Collections.Generic;

namespace Ascending_Tree
{
    public class Node
    {
        public Node LeftChild { get; set; }
        public Node RightChild { get; set; }
        public int Weight { get; set; }
        
    }
    
    class Program
    {

        // Simple implementation of Insertion Sort. 
        //Not very good since it has time complexity of O(n²) but to used it avoid Sort() function 
       // (which is more efficent of course, probably using a quicksort or a more sophisticaded algorithm)

        static List<int> MyInsertionSort(List<int> list)
        {
            for(int i = 0; i < list.Count-1; i++)
            {
                for(int j = i + 1; j > 0; j--)
                {
                    if (list[j-1] > list[j])
                    {
                        int local = list[j-1];
                        list[j-1] = list[j];
                        list[j] = local;
                    }
                  }
            }

            return list; 
        }
        static List<int> ans = new List<int>();
        public static List<int> GetOrderedWeights(Node root)
        {
            // Gets the weights from left to right recursively 

            if(root.LeftChild!=null)
                GetOrderedWeights(root.LeftChild);

            if(root.RightChild!=null)
                GetOrderedWeights(root.RightChild);

            ans.Add(root.Weight);            
            return MyInsertionSort(ans);
        }
        static void Main(string[] args)
        {   
            //Testing with a simple example
            Node root = new Node();
            root.Weight = 100;
            root.LeftChild = new Node();
            root.RightChild = new Node();
            root.LeftChild.Weight = 4;
            root.RightChild.Weight = 3;

            List<int> numbers = GetOrderedWeights(root);
            
            foreach(int x in numbers)
            {
                Console.WriteLine(x.ToString());
            }
        }
    }
}
