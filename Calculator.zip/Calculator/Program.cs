﻿using System;
using System.Text.RegularExpressions;

namespace Neustar
{
public class Calculator
{
	public int Add(int a, int b) { return a + b; }
}

public class Logger
{
	public void Log(string message) { Console.WriteLine(message); }
}

public class Program
{
	public static void Main(string[] args)
	{
        Calculator cal = new Calculator();
        Logger log = new Logger();
        int a = 0, b = 0, ans = 0;
        string val;

        log.Log("--Mega Calculator--"+"\n");
        log.Log("This program calculates the sum of 2 numbers. Please insert only numbers");
        
        
        Regex regex = new Regex(@"^\d+$");
        bool flag = false;

        while(!flag)
        {
            Console.Write("Insert the first number and press enter: ");
            val = Console.ReadLine();
            if(regex.IsMatch(val))
            {
                a = Convert.ToInt32(val);
                flag = true;
                log.Log("First number is: "+a.ToString());
            }
            else
            {
                log.Log("-"+val+"-"+" is not a number. Please try again.");
            }
        }

            flag = false;
                       

        while(!flag)
        {
            Console.Write("Insert the second number and press enter: ");
            val = Console.ReadLine();
            if(regex.IsMatch(val))
            {
                b = Convert.ToInt32(val);
                flag = true;
                log.Log("Second number is: "+b.ToString());
            }
            else
            {
                log.Log("-"+val+"-"+" is not a number. Please try again: ");
            }
        }

        ans = a + b;
        log.Log("The result of a + b = "+ (a+b).ToString() );

        

	}
}
}
