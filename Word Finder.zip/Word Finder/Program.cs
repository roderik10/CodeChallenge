﻿using System;
using System.Text.RegularExpressions;

namespace Word_Finder
{
    class Program
    {
        //Could have been more efficent by implementing the solution 
        //using threads to search both columns and rows at the same time.
        //Didn't do it because inherent overhead on this case was not worth it
        static bool WordFinder(string word, char[,] puzzle)
        {
            string pattern = @"("+word+@")";
            string temp = "";
            bool found = false;
            int rows, columns;
            rows = puzzle.GetLength(0);
            columns = puzzle.GetLength(1);

            // Checks all rows
            for(int i=0; i<rows && !found; i++)
            {
                for(int j=0; j<columns && !found; j++)
                {
                    temp += puzzle[i,j].ToString();
                }
                if(Regex.IsMatch(temp, pattern))
                {
                    found = true;
                }
                else
                {
                    temp = "";
                }
            }

            // Checks all columns
            for(int i=0; i<columns && !found; i++)
            {
                for(int j=0; j<rows && !found; j++)
                {
                    temp += puzzle[j,i].ToString();
                }
                if(Regex.IsMatch(temp, pattern))
                {
                    found = true;
                }
                else
                {
                    temp = "";
                }
            }            
            return found;
        }
        
        static void Main(string[] args)
        {
            string word = "dog";
            char[,] puzzle = new char[3, 3] { { 'x', 'y', 'z' }, { 'd', 'o', 'g' },
                                       { 'a', 'b', 'c' }};

            if(WordFinder(word, puzzle)) Console.WriteLine("Found!");
        }
    }
}
